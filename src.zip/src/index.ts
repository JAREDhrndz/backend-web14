import express from 'express';
import morgan from 'morgan';
import authRoutes from './routes/auth.routes';
import orderRoutes from './routes/order.routes'; // órdenes
import productRoutes from "./routes/product.routes"; // productos
import { connect } from 'http2';
import connectDBmongo from './config/db';

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(morgan('dev'));

// Rutas
app.use('/api/auth', authRoutes);
app.use('/api/orders', orderRoutes); // órdenes
app.use('/api/products', productRoutes); // productos

// Conexión a MongoDB
connectDBmongo().then(() => {
    app.listen(PORT, () => {
        console.log(`El servidor esta corriendo en el puerto: ${PORT}`);
    });
});

